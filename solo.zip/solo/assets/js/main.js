// Menu Categories
function toggleMenuCate() {
    var menuCate = document.getElementById("myMenuCate");
    if (menuCate.style.display === "none" || menuCate.style.display === "") {
        menuCate.style.display = "block";
    } else {
        menuCate.style.display = "none";
    }
}

// Mobile Menu
console.clear();

const navExpand = document.querySelectorAll('.nav-expand');
const backLink = `<li class="nav-item"><a href="javascript:;" class="nav-link nav-back-link"><i class="fa-solid fa-caret-left"></i></a></li>`;

navExpand.forEach(item => {
    item.querySelector('.nav-expand-content').insertAdjacentHTML('afterbegin', backLink);
    const navLink = item.querySelector('.nav-link');
    navLink.addEventListener('click', () => item.classList.toggle('active'));
    item.querySelector('.nav-back-link').addEventListener('click', () => item.classList.remove('active'));
});

const hamIcon = document.getElementById('ham');
hamIcon.addEventListener('click', () => {
    document.body.classList.toggle('nav-is-toggled');
    hamIcon.innerHTML = (hamIcon.innerHTML === `<i class="fas fa-bars"></i>`) ? `<i class="fas fa-times"></i>` : `<i class="fas fa-bars"></i>`;
});


//Price Colorizer
var priceContainers = document.querySelectorAll('.price');

priceContainers.forEach(function(priceContainer) {
    var priceHeading = priceContainer.querySelector('.price-heading');
    var hasDiscount = priceContainer.querySelector('span') !== null;

    if (hasDiscount) {
        priceHeading.classList.add('red-text');
    } else {
        priceHeading.classList.add('black-text');
    }
});